The high-order tensor SVD toolbox with any linear invertible transform L is attributed by:
Wenjin, Qin and Hailin, Wang and Feng, Zhang and Jianjun, Wang et.al.,
If you use any of these tools, please cite:
@ARTICLE{9730793,
  author={Qin, Wenjin and Wang, Hailin and Zhang, Feng and Wang, Jianjun and Luo, Xin and Huang, Tingwen},
  journal={IEEE Transactions on Image Processing}, 
  title={Low-Rank High-Order Tensor Completion With Applications in Visual Data}, 
  year={2022},
  volume={31},
  number={},
  pages={2433-2448},
  doi={10.1109/TIP.2022.3155949}}