function psnr = PSNR_high(Xfull,Xrecover,maxP)

% Written by Canyi Lu (canyilu@gmail.com)

Xrecover = max(0,Xrecover);
Xrecover = min(maxP,Xrecover);
dim = size(Xrecover);
MSE = norm(Xfull(:)-Xrecover(:))^2/(prod(dim));
psnr = 10*log10(maxP^2/MSE);