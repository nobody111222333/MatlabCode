clear all;clc;
addpath(genpath(cd))

load('img_data.mat');
dim=size(data);
X=zeros(dim(1),dim(2),3,dim(3)/3);
for i=1:50
  X(:,:,:,i)=double(data(:,:,3*(i-1)+1:3*i));
end
   
[~, ~, ~, n4] = size(X);
NewSq = randperm(n4);
[~, invNewSq] = sort(NewSq);

X = X(:, :, :, NewSq); 
if (max(X(:)) > 1)
    X = X / 255;
end

maxP = max(abs(X(:)));
dimX = size(X);

% sampling rate
p = 0.7;

 
 
opts.Hset = [3, 4];
opts.mode = [];
omega = find(rand(prod(dimX), 1) < p);
M = zeros(dimX);
M(omega) = X(omega);
opts.DEBUG = 1;
tic
[Xhat, E, err, iter] = TCU1_PADMM(M, omega, opts);
toc

Mhat = max(Xhat, 0);
Mhat = min(Mhat, maxP);
psnr1 = PSNR_high(X, M, maxP)
psnr2 = PSNR_high(X(:, :, :, invNewSq), Mhat(:, :, :, invNewSq), maxP)

filename = ['BSD_TCU1' datestr(now, 'yyyy-mm-dd_HH--MM--SS') '.mat']; %
save(filename, 'psnr2', "Mhat", 'psnr1', 'NewSq');

rmpath(genpath(cd))
