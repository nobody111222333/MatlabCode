
clear all;clc;
addpath(genpath(cd))

load('img_data.mat');
dim=size(data);
X=zeros(dim(1),dim(2),3,dim(3)/3);
for i=1:50
  X(:,:,:,i)=double(data(:,:,3*(i-1)+1:3*i));
end
   
[~, ~, ~, n4] = size(X);
NewSq = randperm(n4);
[~, invNewSq] = sort(NewSq);

X = X(:, :, :, NewSq); 
if (max(X(:)) > 1)
    X = X / 255;
end

maxP = max(abs(X(:)));
dimX = size(X);

% sampling rate
p = 0.7;

 
 
opts.Hset = [1,4];
opts.mode = [2,3];
omega = find(rand(prod(dimX), 1) < p);
M = zeros(dimX);
M(omega) = X(omega);
opts.DEBUG = 1;
tic
[Xhat, E, err, iter] = TCSL_PADMM(M, omega, opts);
%Xhat=M;
toc

Mhat = max(Xhat, 0);
Mhat = min(Mhat, maxP);
psnr1 = PSNR_high(X, M, maxP)
psnr2 = PSNR_high(X(:, :, :, invNewSq), Mhat(:, :, :, invNewSq), maxP)

filename = ['BSD_TCSL' datestr(now, 'yyyy-mm-dd_HH--MM--SS') '.mat'];
save(filename, 'psnr1', 'psnr2', 'NewSq', 'Mhat');

rmpath(genpath(cd))


